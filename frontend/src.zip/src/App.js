import React from 'react';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Call Campaign Manager</h1>
        <p>Aplicación en desarrollo</p>
      </header>
    </div>
  );
}

export default App;
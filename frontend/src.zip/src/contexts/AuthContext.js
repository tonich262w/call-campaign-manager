import React, { createContext, useState, useEffect } from 'react';
import { authService } from '../services/authService';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Verificar si hay token en localStorage
    const checkAuth = async () => {
      const token = localStorage.getItem('token');
      
      if (token) {
        try {
          // Obtener perfil de usuario con el token
          const profile = await authService.getProfile();
          setUser(profile);
        } catch (error) {
          // Si hay error, limpiar token (podría estar expirado)
          console.error('Error al verificar token:', error);
          localStorage.removeItem('token');
        }
      }
      
      setLoading(false);
    };
    
    checkAuth();
  }, []);

  // Iniciar sesión
  const login = async (credentials) => {
    try {
      setError(null);
      const data = await authService.login(credentials);
      
      // Guardar token en localStorage
      localStorage.setItem('token', data.token);
      
      // Establecer usuario
      setUser(data);
      
      return data;
    } catch (err) {
      setError(err.response?.data?.message || 'Error al iniciar sesión');
      throw err;
    }
  };

  // Registrar usuario
  const register = async (userData) => {
    try {
      setError(null);
      const data = await authService.register(userData);
      
      // Guardar token en localStorage
      localStorage.setItem('token', data.token);
      
      // Establecer usuario
      setUser(data);
      
      return data;
    } catch (err) {
      setError(err.response?.data?.message || 'Error al registrar usuario');
      throw err;
    }
  };

  // Cerrar sesión
  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  // Actualizar perfil
  const updateProfile = async (userData) => {
    try {
      setError(null);
      const updatedUser = await authService.updateProfile(userData);
      setUser(updatedUser);
      return updatedUser;
    } catch (err) {
      setError(err.response?.data?.message || 'Error al actualizar perfil');
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        setUser,
        loading,
        error,
        login,
        register,
        logout,
        updateProfile,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
